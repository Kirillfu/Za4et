package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    Spinner days, month, years, gender;
    EditText number, number1;

    // Для отправки запроса
    private int sendPost(String[] params) throws Exception {

        String url = "http://abashin.ru/cgi-bin/ru/tests/burnout";
        //Преводим в URL
        URL obj = new URL(url);
        //открыли соединение
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        //в строку присвоили параметры
        String urlParameters = "day="+params[0]+"&month="+params[1]+"&year="+params[2] +
                "&sex="+params[3]+"&m1="+params[4]+"&m2="+params[5];

        con.setDoOutput(true);
        //создаем объект для записи
        DataOutputStream dataoutput = new DataOutputStream(con.getOutputStream());
        //переносим в объект  параметры
        dataoutput.writeBytes(urlParameters);
        //очищаем и закрываем поток
        dataoutput.flush();
        dataoutput.close();
        //создание входного посимвольного потока
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        //читам ответ и добавляем в inputline
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        String ans = response.toString();

        // Распечатываем результат
        int resi = 0;
        if (ans.contains("отсутствию переутомления")) {
            resi = 1;
        } else if (ans.contains("небольшому переутомлению")) {
            resi = 2;
        } else if (ans.contains("высокому уровню переутомления")) {
            resi = 3;
        }
        return resi;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //объявляем переменные
        Button btnn;
        days = findViewById(R.id.spinner1);
        month = findViewById(R.id.spinner2);
        years = findViewById(R.id.spinner3);
        gender = findViewById(R.id.spinner4);
        number = findViewById(R.id.editTextNumber);
        number1 = findViewById(R.id.editTextNumber1);
        btnn = (Button) findViewById(R.id.btnn);

        btnn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Thread thread = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // Перевод данных пользователя для создания запроса
                                String day = days.getSelectedItem().toString();
                                String mon = month.getSelectedItem().toString();
                                String year = years.getSelectedItem().toString();
                                String sex = gender.getSelectedItem().toString();
                                if (sex == "муж") {
                                    sex = "1";
                                } else {
                                    sex = "2";
                                }
                                String m1 = number.getText().toString();
                                String m2 = number1.getText().toString();
                                String[] params = new String[]{day, mon, year, sex, m1, m2};
                                int number = 0;
                                //Проверка на ошибки
                                try {
                                    number = sendPost(params);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                //Страница без утомления
                                if (number == 1) {
                                    Intent intent = new Intent("com.example.myapplication.sec1");
                                    startActivity(intent);
                                }
                                //Старинца со средним утомлением
                                if (number == 2) {
                                    Intent intent2 = new Intent("com.example.myapplication.sec2");
                                    startActivity(intent2);
                                }
                                //Страница с утомлением
                                if (number == 3) {
                                    Intent intent3 = new Intent("com.example.myapplication.sec3");
                                    startActivity(intent3);
                                }
                                //Страница с ошибками
                                if (number == 0) {
                                    Intent intent4 = new Intent("com.example.myapplication.error");
                                    startActivity(intent4);
                                }

                            }

                        });
                        thread.start();
                    }
                }


        );
    }


}